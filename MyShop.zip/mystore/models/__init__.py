from .product import Product
from .category import Category
from django.shortcuts import render
from .customer import Customer
from .orders import Order
