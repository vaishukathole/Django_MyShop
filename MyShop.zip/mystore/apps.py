from django.apps import AppConfig

from django.urls import path, include
class MystoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mystore'
